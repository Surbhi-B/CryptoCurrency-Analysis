import numpy as np
import pandas as pd
import tensorflow as tf
import tensorflow.python.keras
from tensorflow import keras
import math
from keras.models import Sequential
from keras.layers import Dense, Dropout, Activation, Flatten
#from keras import Dropout

#DATA PROCESSING HERE

#DECIDE TRAINING AND TESTING DATA SETS

#Performing Feature Scaling
#from sklearn.preprocessing import StandardScaler

#Initialising ANN
ann = tf.keras.models.Sequential()
#Adding First Hidden Layer
ann.add(tf.keras.layers.Dense(units=6, input_dim=3, activation="relu"))
# 1. units:- number of neurons that will be present in the respective layer
#2. activation:- specify which activation function to be used
#Dropout Layers-remove some random nodes:
#ann.add(Dropout(0.2))
#Adding Second Hidden Layer
ann.add(tf.keras.layers.Dense(units=6, activation="relu"))
layer = tf.keras.layers.Dropout(.15)
#Adding Output Layer
ann.add(tf.keras.layers.Dense(units=5, activation="sigmoid"))

msle = tf.keras.losses.MeanSquaredLogarithmicError()
#Compiling ANN
ann.compile(optimizer="adam", loss= msle, metrics=['accuracy'])

#Saving created neural network
ann.save("ANN.h5")

# open file2
CryptoPrices = open('CurrencyPricesNN.csv','r')
y_train = []
skipIndices = []
count = 1
for line2 in CryptoPrices.read().split("\n")[1:]:
    data2 = line2.split(',')
    #print(data2)
    if 'null' not in data2 and '' not in data2:
        y_train.append([float(data2[4]), float(data2[5]), float(data2[6]), float(data2[7]), float(data2[8])])
    else:
        skipIndices.append(count)
    count = count +1
print(len(skipIndices))
#print(y_train)
y_train = y_train[0:math.floor(len(y_train) * 0.9)-1]
y_test = y_train[math.floor(len(y_train) * 0.9):]

# open file
CovidDeaths= open('us copy.csv')
X_train = []
X_test = []
count2 = 1
for line in CovidDeaths.read().split("\n")[1:]:
    if count2 not in skipIndices:
        data = line.split(',')
        X_train.append([float(data[4]), float(data[5]), float(data[6])])
    count2 = count2+1
np.array(X_train)
#print(X_train)
X_train = X_train[0:math.floor(len(X_train) * 0.9)-1]
X_test = X_train[math.floor(len(X_train) * 0.9):]



X_train = np.asarray(X_train)
y_train = np.asarray(y_train)
X_test = np.asarray(X_test)
y_test = np.asarray(y_test)

ann.fit(X_train, y_train, batch_size=100, epochs=5, validation_data=(X_test, y_test), shuffle=True)
ann.save("ANN.h5")
# c0, c1, c2, c3, c4 = ann.predict(cov0, cov1, cov2)
