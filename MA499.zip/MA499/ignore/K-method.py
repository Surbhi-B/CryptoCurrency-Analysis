# from pandas_datareader import data 
# import pandas as pd
# import numpy as np

dataDict={}
Data = open('files.txt', 'r')

with open('filenames.txt') as file:
    lines = file.readlines()

for currency in lines:
    dataDict[currency] = 0

print(dataDict)