# Takes in a filename, gets all the columns from that file and returns them
def getListsFromFile(filename):
    list0 = []
    list1 = []
    list2 = []
    list3 = []
    list4 = []
    list5 = []
    list6 = []
    print("THIS IS THE FILE: " + filename)
    file = open("Crypto Data/" + filename.strip())
    for chunks in file.read().split("\n"):

        col = chunks.split(',')
        if col[1] != "null" or col[0] != "null":
            list0.append(col[0])
            list1.append(col[1])
            list2.append(col[2])
            list3.append(col[3])
            list4.append(col[4])
            list5.append(col[5])
            list6.append(col[6])
    # # open filename
    # for each row in file add row[0] to list0, row[1] to list[1], etc.
    #print(list1)
    return(list0, list1, list2, list3, list4, list5, list6)


# Takes in required data and calculates volatility
def calculateMean(colA):
    sum = 0
    for val in colA[1:]:
        if val != "null":
            sum = sum + float(val)
    mean = sum/(len(colA)+1)
    return mean
    # add volatility code

def calculateVolatility(colA, mean):
    sumList=[]
    for val in colA[1:]:
        if val != "null":
            sd = (float(val)-float(mean))**(2)
            sumList.append(sd)
    volatility= sum(sumList)/len(colA)
    return volatility

def calculateNetChange(colA):
    pass
    # add calculation


def calculator():
    all_means = {}
    all_volatility={}
    currencyList = list(open('filenameList'))
    currencyList1 = [line.rstrip('\0') for line in currencyList]
    for line in currencyList1:
        if(line is None):
            break
        list0, list1, list2, list3, list4, list5, list6 = getListsFromFile(
            line)
        mean = calculateMean(list4)
        volatility= calculateVolatility(list4, mean)
        all_volatility[line] = volatility
        #print(volatility)
        all_means[line] = mean



    print(all_means)
    all_net_changes = []
    #for file in all_files:
        #list0, list1, list2, list3, list4, list5, list6 = getListsFromFile(file)
        # volatility = calculateVolatility(list1, list5)
        # all_volatility.append(volatility)
        # net_change = calculateNetChange(list3)
        # all_net_changes.append(net_change)


#getListsFromFile('ADA-USD.csv')
# k-means on all_volatility list
# plots on final calcs
calculator()