import pandas as pd
from matplotlib import pyplot as plt

covid_death_rate = pd.read_csv('us.csv', usecols = ['date','deaths'])
bitcoin = pd.read_csv('Crypto Data/MKR-USD.csv', usecols = ['Date','Adj Close'])
bitcoin['Adj Close'].convert_dtypes(pd.Series)
pd.to_numeric(bitcoin['Adj Close'], errors='coerce')
bitcoin['Adj Close'].dropna()
covid_death_rate['deaths']
print(covid_death_rate)
#plt.plot(covid_death_rate['deaths_avg_per_100k'][0:708], bitcoin['Adj Close'])
#plt.show()

plt.plot(covid_death_rate['date'][0:708], covid_death_rate['deaths'][0:708], 'r--', bitcoin['Date'], bitcoin['Adj Close'], 'bs')
plt.show()