from sklearn.cluster import KMeans
import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
sns.set(style="darkgrid")
import warnings
warnings.filterwarnings("ignore")
import csv

# with open("crypto_df.csv") as csv_file:
#     # read the csv file
#     csv_reader = csv.reader(csv_file)
 
# now we can use this csv files into the pandas
df = pd.read_table("crypto_df.csv", delimiter =",")
print(df.head())

# X = df.filter(["Volume", "AvgPrice" ], axis = 1)
# model = KMeans(n_clusters= 4)
# model.fit(X)
# print(model.cluster_centers_)
#g = sns.pairplot(df)
sns.set(style="ticks", color_codes=True) # change style
g = sns.pairplot(df, hue="Currency")
plt.show()
