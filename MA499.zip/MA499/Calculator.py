from csv import reader

volatilities = dict()
def importData(self):
    currency_list = open("files - Copy.txt")
    r=currency_list.read()
    for row in r:
        stockVol = self.calcVolatility(self,row)
        volatilities[row] = stockVol
    print(volatilities)
    return 0
def calcVolatility(currencyName):
    print("start this please")
    return 0
def calcStability():
    print("ples")
    return 0
