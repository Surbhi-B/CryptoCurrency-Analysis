import matplotlib.pyplot as plt
from sklearn.cluster import KMeans
import csv


# Takes in a filename, gets all the columns from that file and returns them
def getListsFromFile(filename):
    list0 = []
    list1 = []
    list2 = []
    list3 = []
    list4 = []
    list5 = []
    list6 = []
    #print("THIS IS THE FILE: " + filename)
    file = open('Crypto Data/' + filename.strip())
    for chunks in file.read().split("\n"):

        col = chunks.split(',')
        if col[1] != "null" or col[0] != "null":
            list0.append(col[0])
            list1.append(col[1])
            list2.append(col[2])
            list3.append(col[3])
            list4.append(col[4])
            list5.append(col[5])
            list6.append(col[6])
    # # open filename
    # for each row in file add row[0] to list0, row[1] to list[1], etc.
    #print(list1)
    return(list0, list1, list2, list3, list4, list5, list6)

def calculateWeeklyVolume(high, low, close, volume):
    #sigPrice *volume/ sigVolume
    #price is high+low+close /3
    high = [i for i in high if i != 'null']
    low = [i for i in low if i != 'null']
    close = [i for i in close if i != 'null']
    volume = [i for i in volume if i != 'null']
    tempPrice = []
    tempVolume=[]
    count = 0
    output = []
    for i in range(1,min(len(close),len(volume),len(high), len(low))):
        if high[i] != "null" or low[i] !='null' or volume[i] != 'null':
            tempPrice.append(float(high[i])+float(low[i])+float(close[i])/3)
            tempVolume.append(float(volume[i]))
            count= count + 1
            if count == 7:
                output.append((sum(tempPrice)*float(volume[i]))/sum(tempVolume))
                tempPrice=[]
                tempVolume=[]
                count=0
    if count < 7:
        if high[i] != "null":
            tempPrice.append(float(high[i])+float(low[i])+float(close[i])/3)
            tempVolume.append(float(volume[i]))
            count= count + 1
            if count == 7:
                output.append((sum(tempPrice)*float(volume[i]))/sum(tempVolume))
        return output
    return output

def calculateVolume(colA):
    sum = 0
    for val in colA[1:]:
        if val != "null":
            sum = sum + float(val)
    volumeAv = sum/(len(colA)+1)
    return volumeAv

def calculateInfectionsVolumeRatio(colA):
    covidInfections = open("us copy.csv","r")
    #InfectionAvg = covidInfections['cases_avg_per_100k'].tolist()
    InfectionAvg=[]
    for chunks in covidInfections.read().split("\n"):
        col = chunks.split(',')
        if col[4] != 'cases_avg_per_100k':
            InfectionAvg.append(float(col[4]))
    #709
    colA.pop(0)
    # print("THIS IS THE LIST: " )
    # print(colA)
    colA = [i for i in colA if i != 'null']
    # for item in colA:
    #     if item == 'null':
    #         colA.remove('null')
    colA = list(map(float, colA))
    #print(colA)
    #for i in range(0,679):
    avVolume= sum(colA)/(len(colA)-1)
    avInfectionRate = sum(InfectionAvg)/(len(InfectionAvg) -1)
    volToInf = (avVolume/avInfectionRate)/100000
    covidInfections.close()
    return volToInf

# Takes in required data and calculates volatility
def calculateMean(colA):
    sum = 0
    for val in colA[1:]:
        if val != "null":
            sum = sum + float(val)
    mean = sum/(len(colA)+1)
    return mean
    # add volatility code


def calculateVolatility(colA, mean):
    sumList = []
    for val in colA[1:]:
        if val != "null":
            sd = (float(val)-float(mean))**(2)
            sumList.append(sd)
    volatility = sum(sumList)/len(colA)
    return volatility


def calculateWeeklyVolatilities(colA):
    temp = []
    count = 0
    output = []
    for val in colA[1:]:
        if val != "null":
            temp.append(float(val))
            count += 1
            if count == 7:
                volatilities = []
                mean = sum(temp) / len(temp)
                for num in temp:
                    sd = (float(val)-float(mean))**(2)
                    volatilities.append(sd)
                output.append(sum(volatilities) / len(volatilities))
                temp = []
                count = 0
    if len(temp) > 0:
        #print(len(temp))
        volatilities = []
        mean = sum(temp) / len(temp)
        for num in temp:
            sd = (float(val)-float(mean))**(2)
            volatilities.append(sd)
        output.append(sum(volatilities) / len(volatilities))
    return output


def calculator():
    all_means = {}
    all_volatility = {}
    all_weekly_volumes = {}
    # keys are filenames: value is the list of weekly volatilities
    all_weekly_volatilities = {}
    currencyList = list(open('filenameList'))
    currencyList1 = [line.rstrip('\0') for line in currencyList]
    f2= open("crypto_df.csv", "a")
    f2.write("Currency, Volume, AvgPrice, Volatility, Volume:InfectionRate\n")
    #f3=open("CurrencyPrices.csv","a",newline='')
    #wr = csv.writer(f3, quoting=csv.QUOTE_ALL)
    prices=[]
    for line in currencyList1:
        if(line is None):
            break
        list0, list1, list2, list3, list4, list5, list6 = getListsFromFile(
            line)
        mean = calculateMean(list4)
        volume = calculateVolume(list6)
        returns = calculateInfectionsVolumeRatio(list6)
        volatility = calculateVolatility(list4, mean)
        all_volatility[line] = volatility
        all_means[line] = mean
        all_weekly_volatilities[line.strip(
        )] = calculateWeeklyVolatilities(list4)
        volumeAv = calculateWeeklyVolume(list2,list3,list4,list6)
        all_weekly_volumes[line.strip()] = volumeAv
        f2.write(str(line.strip())+","+str(volume)+","+str(mean)+","+str(volatility)+","+str(returns)+"\n")
    f2.close()
        #f3.write(line)
    #prices.append(list4)
        # for word in list4[1:]:
        #     if(word!="null"):
        #         wr.writerow([float(word.strip())])
    # for i in range(0,10):
    #     f3.write(str(prices[i][0]) +','+ str(prices[i][1])+',' +str(prices[i][2]))
        # print(all_volatility)
        #for file in all_files:
        #list0, list1, list2, list3, list4, list5, list6 = getListsFromFile(file)
        # volatility = calculateVolatility(list1, list5)
        # all_volatility.append(volatility)
        # net_change = calculateNetChange(list3)
        # all_net_changes.append(net_change)
    # f= open("weeklyVolatilities", "a")
    # table1 = json.dumps(all_weekly_volatilities)
    # f.write(table1)
    # f.close()
    # f= open("allVolatilities", "a")
    # table2 = json.dumps(all_volatility)
    # f.write(table2)
    # f.close()
    #f3.close()
    
        #getListsFromFile('ADA-USD.csv')
        # k-means on all_volatility list
        # plots on final calcs
    all_weekly_volatility_keys = all_weekly_volatilities.keys()
    all_weekly_volatility_values = list(all_weekly_volatilities.values())
    all_weekly_volumes_values = list(all_weekly_volumes.values())
    # k-means code
    #print(all_weekly_volumes)


    # arrArr = [[5,2,3,4], [2,2,3,4], [3,2,3,4], [4,2,3,4]]
    # print(sorted(arrArr, key = lambda x: x[0]))
    # print([value for value in arrArr])
    # sort_by_first = sorted(all_weekly_volatilities.values(),key = lambda x: x[0])
    # print(sorted(all_weekly_volatilities.values(),key = lambda x: x[0]))
    
    #want to plot timexvolumexvolatility
    # arr=[]
    # for i in range(0,100):
    #     arr.append(int(i))
    # for i in range(len(arr)-1):
    #     plt.plot(all_weekly_volatility_values[i-1], all_weekly_volumes_values[i])
    # plt.show()
#sklearn
    #make tuple with time


    # plt.plot(sort_by_first, range(len(sort_by_first)))
    
    
    

    #Reformat into 23x50something matrix

# def kOptimize():
#     cost =[]
#     for i in range(1, 11):
#         KM = KMeans(n_clusters = i, max_iter = 500)
#         KM.fit(X)
        
#         # calculates squared error
#         # for the clustered points
#         cost.append(KM.inertia_)    
    
#     # plot the cost against K values
#     plt.plot(range(1, 11), cost, color ='g', linewidth ='3')
#     plt.xlabel("Value of K")
#     plt.ylabel("Squared Error (Cost)")
#     plt.show() # clear the plot


calculator()
